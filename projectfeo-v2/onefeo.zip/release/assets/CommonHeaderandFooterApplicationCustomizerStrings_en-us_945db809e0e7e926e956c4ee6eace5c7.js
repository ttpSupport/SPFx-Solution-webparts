define([], function() {
  return {
    "Title": "CommonHeaderandFooterApplicationCustomizer"
  }
});