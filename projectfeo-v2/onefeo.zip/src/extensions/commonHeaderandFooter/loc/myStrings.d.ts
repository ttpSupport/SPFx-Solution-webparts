declare interface ICommonHeaderandFooterApplicationCustomizerStrings {
  Title: string;
  FooterMessage:String;
}

declare module 'CommonHeaderandFooterApplicationCustomizerStrings' {
  const strings: ICommonHeaderandFooterApplicationCustomizerStrings;
  export = strings;
}
