/* tslint:disable */
require("./SiteBreadcrumb.module.css");
const styles = {
  breadcrumb: 'breadcrumb_695c84ea',
  msBgColorThemePrimary: 'msBgColorThemePrimary_695c84ea',
  breadcrumbLinks: 'breadcrumbLinks_695c84ea'
};

export default styles;
/* tslint:enable */