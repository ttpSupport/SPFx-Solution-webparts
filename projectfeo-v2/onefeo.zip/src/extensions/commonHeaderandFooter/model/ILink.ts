// Any menu link
export default interface ILink {
    name: string;
    url: string;
    children: ILink[];
}