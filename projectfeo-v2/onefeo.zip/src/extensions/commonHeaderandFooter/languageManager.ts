import * as strings from 'CommonHeaderandFooterApplicationCustomizerStrings';

export class languageManager {

    public static GetStrings(): ICommonHeaderandFooterApplicationCustomizerStrings {
        return strings;
    }

}