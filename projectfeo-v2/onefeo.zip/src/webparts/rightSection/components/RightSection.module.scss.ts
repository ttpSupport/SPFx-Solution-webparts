/* tslint:disable */
require("./RightSection.module.css");
const styles = {
  rightSection: 'rightSection_815129bd',
  teams: 'teams_815129bd',
  welcome: 'welcome_815129bd',
  welcomeImage: 'welcomeImage_815129bd',
  links: 'links_815129bd'
};

export default styles;
/* tslint:enable */