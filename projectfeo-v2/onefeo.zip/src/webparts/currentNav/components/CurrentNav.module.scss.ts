/* tslint:disable */
require("./CurrentNav.module.css");
const styles = {
  currentNav: 'currentNav_194c88f7',
  teams: 'teams_194c88f7',
  welcome: 'welcome_194c88f7',
  welcomeImage: 'welcomeImage_194c88f7',
  links: 'links_194c88f7'
};

export default styles;
/* tslint:enable */