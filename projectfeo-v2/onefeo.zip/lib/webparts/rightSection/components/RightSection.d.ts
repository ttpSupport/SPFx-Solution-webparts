import * as React from 'react';
import { IRightSectionProps } from './IRightSectionProps';
export default class RightSection extends React.Component<IRightSectionProps, {}> {
    render(): React.ReactElement<IRightSectionProps>;
}
//# sourceMappingURL=RightSection.d.ts.map