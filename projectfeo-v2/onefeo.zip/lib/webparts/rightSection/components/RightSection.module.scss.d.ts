declare const styles: {
    rightSection: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=RightSection.module.scss.d.ts.map