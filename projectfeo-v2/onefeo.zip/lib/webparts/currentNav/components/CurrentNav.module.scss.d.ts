declare const styles: {
    currentNav: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=CurrentNav.module.scss.d.ts.map