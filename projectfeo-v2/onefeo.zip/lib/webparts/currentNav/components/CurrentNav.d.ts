import * as React from 'react';
import { ICurrentNavProps } from './ICurrentNavProps';
export default class CurrentNav extends React.Component<ICurrentNavProps, {}> {
    render(): React.ReactElement<ICurrentNavProps>;
}
//# sourceMappingURL=CurrentNav.d.ts.map