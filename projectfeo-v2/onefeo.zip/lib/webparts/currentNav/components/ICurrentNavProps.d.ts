export interface ICurrentNavProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
}
//# sourceMappingURL=ICurrentNavProps.d.ts.map