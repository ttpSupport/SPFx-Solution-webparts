import * as React from 'react';
import ILink from '../model/ILink';
export interface IHeaderProps {
    links: ILink[];
}
export declare class Header extends React.Component<IHeaderProps, {}> {
    constructor(props: IHeaderProps);
    render(): JSX.Element;
}
//# sourceMappingURL=Header.d.ts.map