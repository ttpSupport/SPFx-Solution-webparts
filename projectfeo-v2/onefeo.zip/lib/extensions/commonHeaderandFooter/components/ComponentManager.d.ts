import IHeaderFooterData from '../model/IHeaderFooterData';
export default class ComponentManager {
    static render(headerDomElement: HTMLElement, footerDomElement: HTMLElement, data: IHeaderFooterData): void;
}
//# sourceMappingURL=ComponentManager.d.ts.map