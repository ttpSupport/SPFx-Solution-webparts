declare const styles: {};
export default styles;
//# sourceMappingURL=HeaderFooter.scss.d.ts.map