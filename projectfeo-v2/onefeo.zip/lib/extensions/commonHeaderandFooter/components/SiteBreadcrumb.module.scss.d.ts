declare const styles: {
    breadcrumb: string;
    msBgColorThemePrimary: string;
    breadcrumbLinks: string;
};
export default styles;
//# sourceMappingURL=SiteBreadcrumb.module.scss.d.ts.map