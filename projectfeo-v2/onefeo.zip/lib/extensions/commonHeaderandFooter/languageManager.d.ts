export declare class languageManager {
    static GetStrings(): ICommonHeaderandFooterApplicationCustomizerStrings;
}
//# sourceMappingURL=languageManager.d.ts.map