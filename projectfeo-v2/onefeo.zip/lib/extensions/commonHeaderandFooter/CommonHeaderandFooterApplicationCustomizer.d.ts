import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
import 'jquery';
import "@pnp/sp/webs";
import "@pnp/sp/comments/clientside-page";
import "@pnp/sp/clientside-pages/web";
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface ICommonHeaderandFooterApplicationCustomizerProperties {
    testMessage: string;
}
/** A Custom Action which can be run during execution of a Client Side Application */
export default class CommonHeaderandFooterApplicationCustomizer extends BaseApplicationCustomizer<ICommonHeaderandFooterApplicationCustomizerProperties> {
    private _headerPlaceholder;
    private _sp;
    private aadTokenProvider;
    onInit(): Promise<void>;
    private getAccessToken;
    private CheckcurrentPagelayout;
    private bootstrap;
    private _renderPlaceHolders;
    private _onDispose;
}
//# sourceMappingURL=CommonHeaderandFooterApplicationCustomizer.d.ts.map