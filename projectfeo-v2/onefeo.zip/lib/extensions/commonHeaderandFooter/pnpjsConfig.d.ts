import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";
export declare const getSP: (context?: WebPartContext) => SPFI;
//# sourceMappingURL=pnpjsConfig.d.ts.map