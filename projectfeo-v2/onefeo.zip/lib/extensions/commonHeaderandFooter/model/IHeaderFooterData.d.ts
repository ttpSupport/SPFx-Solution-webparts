import ILink from './ILink';
export default interface IHeaderFooterData {
    headerLinks: ILink[];
    footerLinks: ILink[];
}
//# sourceMappingURL=IHeaderFooterData.d.ts.map