export default interface ILink {
    name: string;
    url: string;
    children: ILink[];
}
//# sourceMappingURL=ILink.d.ts.map